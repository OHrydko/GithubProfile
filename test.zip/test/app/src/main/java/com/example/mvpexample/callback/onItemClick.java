package com.example.mvpexample.callback;

public interface onItemClick {
    void click(int position);
}
